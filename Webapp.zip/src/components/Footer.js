import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
        <p>&copy; 2022 blog company</p>
    </div>
  )
}

export default Footer