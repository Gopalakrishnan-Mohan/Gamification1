import React from 'react'

const Hero = () => {
  return (
    <div className='hero'>
        <div className='hero-inner'>
            <h1>Welcome </h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat nesciunt accusantium tempora voluptatem velit enim quaerat sapiente sed, repellat temporibus eaque dignissimos, saepe ab recusandae incidunt fuga veniam vero vitae!</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu molestie justo. Nulla eu arcu ut ex imperdiet facilisis. Mauris bibendum urna nec erat maximus cursus. In mollis, libero ut dignissim semper, massa libero consequat arcu, id cursus sem ligula tincidunt risus. Integer euismod urna elit, et consectetur nunc aliquet id. Fusce in semper massa, sed venenatis lorem. Maecenas non mi eget arcu dictum venenatis. Donec porttitor erat non ornare vulputate. Suspendisse quis augue nibh. Vestibulum tincidunt vehicula dolor at malesuada. Quisque quis dolor eget urna lobortis vehicula. Quisque sit amet tristique mauris, ut lacinia ipsum.

Phasellus dignissim ante neque, vitae vehicula velit lobortis eu. Phasellus faucibus diam id felis semper ultricies. Suspendisse potenti. Cras sagittis ac ante sed porttitor. Sed rhoncus lectus iaculis, pellentesque quam a, facilisis sem. Pellentesque sagittis dolor dictum magna tristique, id faucibus nibh fringilla. Quisque velit odio, faucibus eu nibh vel, interdum eleifend ex. Sed ultricies mi sem, nec porttitor odio convallis vitae.

Aliquam ut suscipit metus. Duis fermentum tempor sapien a facilisis. Donec finibus tellus a viverra vestibulum. Nulla in tortor non sapien volutpat venenatis. Nam commodo turpis sodales tellus lacinia, a pellentesque sem pulvinar. Proin rutrum, erat et bibendum convallis, leo neque fringilla tellus, vel ornare purus mi vel augue. Sed ut interdum neque. Ut auctor odio ac nulla faucibus, vel efficitur neque consequat.

Mauris ultrices aliquam aliquam. Pellentesque congue eros dui, et viverra metus cursus a. Suspendisse congue turpis elit, non fringilla lorem feugiat id. Suspendisse porta erat sollicitudin, pellentesque orci eget, placerat augue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Vestibulum in tincidunt dolor, a vestibulum nisl. Duis semper congue orci, sit amet fermentum nunc imperdiet ut. Donec tincidunt pellentesque dictum. Pellentesque non lectus vestibulum nunc malesuada commodo. Cras gravida mi ipsum, nec elementum libero porta sit amet. Integer vitae cursus nisi, quis tristique augue. Curabitur id enim ac est feugiat blandit sit amet at libero. Phasellus elit sapien, efficitur non volutpat vel, efficitur in magna. Nullam vitae purus enim. Etiam mattis molestie augue, vitae gravida dolor aliquam non. Aenean sit amet dictum elit.

Donec rutrum dictum erat eget laoreet. Nunc lobortis mi nec augue tempor ullamcorper. Fusce at interdum nulla. Nulla lacinia eu lorem non euismod. Morbi tempor metus vitae nunc rhoncus rhoncus. Etiam tristique eros at arcu dignissim vulputate. Sed consectetur eros nec augue tincidunt, quis laoreet diam rutrum. Ut vel ante at quam maximus vulputate. Vestibulum mattis lectus vel dolor accumsan, quis dignissim ante rhoncus. Vivamus malesuada, ipsum in convallis accumsan, ex nisi mattis enim, in dapibus metus arcu a dui. Mauris tempor egestas cursus. Duis nisl nisi, tempus facilisis tellus et, feugiat pulvinar metus.</p>
        </div>    
    </div>
  )
}

export default Hero